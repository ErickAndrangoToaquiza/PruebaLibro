using PruebaLibro.Domain;

namespace PruebaLibro.Application;

public class AutorAppService : IAutorAppService
{

    private readonly IAutorRepository repository;
    private readonly IUnitOfWork unitOfWork;
    public AutorAppService (IAutorRepository repository, IUnitOfWork unitOfWork)
    {
        this.repository=repository;
        this.unitOfWork =unitOfWork;
    }


    public async Task<AutorDto> CreateAsync(AutorCrearActualizarDto autorDto)
    {
        var existeAutor = await repository.ExisteNombre(autorDto.Nombre);
        
        if(existeAutor){
                throw new ArgumentException($"Ya existe {autorDto.Nombre}");
        }
        var autor = new Autor();
        autor.Nombre = autorDto.Nombre;
        autor.Apellido=autorDto.Apellido;
        autor.Sueldo=autorDto.Sueldo;
        autor.AñoPublicacion=autorDto.AñoPublicacion;
        autor.Id=autorDto.Id;
        
       
        
        var autorCreado=new AutorDto();

        autorCreado.LibroId= autor.LibroId;
        autorCreado.Apellido=autor.Apellido;
        autorCreado.Nombre=autor.Nombre;
        autorCreado.Sueldo=autor.Sueldo;

        return autorCreado;
        
       
    }


    public async Task<bool> DeleteAsync(int libroId)
    {
        var editorial =await repository.GetByIdAsync(libroId);
        if (editorial==null){
        throw new ArgumentException($"el producto no existe {libroId}");}

        
        return true;
    }

    public ListaPaginada<AutorDto> GetAll(int limit = 10, int offset = 0)
    {
        var listaEditorial=repository.GetAll().Skip(offset).Take(limit);

        throw new NotImplementedException();
    }

    public  async Task UpdateAsync(int id, AutorCrearActualizarDto libroDto)
    {
        var autor =await repository.GetByIdAsync(id);
        if (autor ==null){
        throw new ArgumentException($"La editorial no existe {id}");}
        var existeAutor =await repository.ExisteNombre(libroDto.Nombre,id);
        if (existeAutor)
        {
            throw new ArgumentException ($"Ya existe el nombre {libroDto.Nombre}");
        }
        autor.Nombre=autor.Nombre;
       

        await repository.UpdateAsync(autor);

        return;
    }
}