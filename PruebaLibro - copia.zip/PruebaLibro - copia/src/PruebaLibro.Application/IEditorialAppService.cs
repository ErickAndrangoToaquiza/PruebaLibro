using System.ComponentModel.DataAnnotations;
using PruebaLibro.Application;
using PruebaLibro.Domain;

namespace PruebaLibro.Application;

    public interface IEditorialAppService
    {
         ListaPaginada <EditorialDto> GetAll (int limit =10, int offset=0);
    Task<EditorialDto> CreateAsync (EditorialCrearActualizarDto libro);

    Task UpdateAsync (int id, EditorialCrearActualizarDto libro);
    Task <bool> DeleteAsync (int libroId);
    }


public class EditorialDto
{
 [Required]

    public int Id {get;set;}

    [Required]
    [StringLength(DominioConstantes.NOMBRE_MAXIMO)]
    public string Nombre {get;set;}

    public string Ciudad {get;set;}

    public decimal Ganancia {get;set;}

    public DateTime? AñoFundacion {get;set;}
    
    [Required]
    public int LibroId {get;set;}
    public virtual Libro Libro {get;set;}
}
public class EditorialCrearActualizarDto
{
public int Id {get;set;}

    [Required]
    [StringLength(DominioConstantes.NOMBRE_MAXIMO)]
    public string Nombre {get;set;}

    public string Ciudad {get;set;}

    public decimal Ganancia {get;set;}

    public DateTime? AñoFundacion {get;set;}
    
    [Required]
    public int LibroId {get;set;}
}