﻿using System.ComponentModel.DataAnnotations;
using PruebaLibro.Domain;

namespace PruebaLibro.Application;


public interface ILibroAppService
{

    ICollection<LibroDto> GetAll();

    Task<LibroDto> CreateAsync(LibroCrearActualizarDto libro);

    Task UpdateAsync (int id, LibroCrearActualizarDto libro);

    Task<bool> DeleteAsync(int libroId);
}
 
 
