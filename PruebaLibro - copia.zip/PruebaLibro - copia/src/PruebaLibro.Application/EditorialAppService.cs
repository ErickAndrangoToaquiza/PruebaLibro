
using System.ComponentModel.DataAnnotations;
using PruebaLibro.Domain;
namespace PruebaLibro.Application;

public class EditorialAppService : IEditorialAppService
{
    private readonly IEditorialRepository repository;
    private readonly IUnitOfWork unitOfWork;

    public EditorialAppService (IEditorialRepository repository,IUnitOfWork unitOfWork){
        this.repository =repository;
        this.unitOfWork =unitOfWork;
    } 

    public  async Task<EditorialDto> CreateAsync (EditorialCrearActualizarDto editorialDto)
    {
        var existeEditorial = await repository.ExisteNombre(editorialDto.Nombre);
        if(existeEditorial){
                throw new ArgumentException($"Ya existe {editorialDto.Nombre}");
        }
        var editorial =new Editorial();
        editorial.Nombre = editorialDto.Nombre;
        editorial.AñoFundacion =editorialDto.AñoFundacion;
        editorial.Ciudad=editorialDto.Ciudad;
        editorial.Ganancia=editorialDto.Ganancia;
        editorial =await repository.AddAsync(editorial);
        var editorialCreado=new EditorialDto();
        editorialCreado.LibroId= editorial.LibroId;
        editorialCreado.Nombre = editorial.Nombre;
        editorialCreado.AñoFundacion =editorial.AñoFundacion;
        editorialCreado.Ciudad=editorial.Ciudad;
        editorialCreado.Ganancia=editorial.Ganancia;

        return editorialCreado;
        
    }

    public async Task<bool> DeleteAsync(int libroId)
    {
        var editorial =await repository.GetByIdAsync(libroId);
        if (editorial==null){
        throw new ArgumentException($"el producto no existe {libroId}");}

        repository.Delete(editorial);
        return true;
    }

    public ListaPaginada<EditorialDto> GetAll(int limit = 10, int offset = 0)
    {
            var listaEditorial=repository.GetAll().Skip(offset).Take(limit);

        throw new NotImplementedException();
    }

    public async Task UpdateAsync(int id, EditorialCrearActualizarDto libroDto)
    {
        var editorial =await repository.GetByIdAsync(id);
        if (editorial ==null){
        throw new ArgumentException($"La editorial no existe {id}");}
        var existeEditorial =await repository.ExisteNombre(libroDto.Nombre,id);
        if (existeEditorial)
        {
            throw new ArgumentException ($"Ya existe el nombre {libroDto.Nombre}");
        }
        editorial.Nombre=editorial.Nombre;
        editorial.Ganancia=editorial.Ganancia;
        editorial.AñoFundacion=editorial.AñoFundacion;

        await repository.UpdateAsync(editorial);

        return;
    }

}
    

