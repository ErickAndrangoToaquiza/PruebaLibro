namespace PruebaLibro.Domain;

public static class DominioConstantes{

    public const int NOMBRE_MAXIMO =50;
}