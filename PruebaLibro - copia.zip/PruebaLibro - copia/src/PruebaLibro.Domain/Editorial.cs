using System.ComponentModel.DataAnnotations;

namespace PruebaLibro.Domain;

public class Editorial
{
    [Required]

    public int Id {get;set;}

    [Required]
    [StringLength(DominioConstantes.NOMBRE_MAXIMO)]
    public string Nombre {get;set;}

    public string Ciudad {get;set;}

    public decimal Ganancia {get;set;}

    public DateTime? AñoFundacion {get;set;}
    
    [Required]
    public int LibroId {get;set;}
    public virtual Libro Libro {get;set;}
}
