using System.ComponentModel.DataAnnotations;

namespace PruebaLibro.Domain;

public class Autor
{
    [Required]

    public int Id {get;set;}

    [Required]
    [StringLength(DominioConstantes.NOMBRE_MAXIMO)]
    public string Nombre {get;set;}

    public string Apellido{get;set;}

    public decimal Sueldo {get;set;}

    public DateTime? AñoPublicacion {get;set;}
    
    [Required]
    public int LibroId {get;set;}
    public virtual Libro Libro {get;set;}
}
