namespace PruebaLibro.Domain;

public interface IAutorRepository : IRepository<Editorial>{
      Task<bool>ExisteNombre (string nombre);
    Task<bool>ExisteNombre(string nombre, int idExcluir);
}