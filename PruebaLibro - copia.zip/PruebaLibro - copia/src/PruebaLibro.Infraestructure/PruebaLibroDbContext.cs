﻿using PruebaLibro.Domain;
using Microsoft.EntityFrameworkCore;


namespace PruebaLibro.Infraestructure;

public class PruebaLibroDbContext:DbContext,IUnitOfWork
{

    //Agregar sus entidades
    public DbSet<Libro>Libros{get;set;}
    public DbSet<Editorial>Editorials{get;set;}
    public DbSet<Autor>Autors{get;set;}
    public string DbPath { get; set; }

    public PruebaLibroDbContext()
    {
        var folder = Environment.SpecialFolder.LocalApplicationData;
        var path = Environment.GetFolderPath(folder);
        DbPath = Path.Join(path, "pruebalibro.db");
 
    }

   protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite($"Data Source={DbPath}");

} 



