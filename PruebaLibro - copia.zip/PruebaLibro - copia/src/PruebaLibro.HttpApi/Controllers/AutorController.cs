using Microsoft.AspNetCore.Mvc;
using PruebaLibro.Application;

namespace PruebaLibro.HttpApi.Controllers;

[ApiController]
[Route ("[controller]")]

public class AutorController : ControllerBase
{
    private readonly IAutorAppService autorAppService;

    public AutorController (IAutorAppService autorAppService)
    {
        this.autorAppService =autorAppService;

    }
[HttpGet]
public ListaPaginada<AutorDto>GetAll (int limit =10, int offset=0)
{
    return autorAppService.GetAll(limit,offset);
}


[HttpPost]
    public async Task<AutorDto> CreateAsync (AutorCrearActualizarDto libro)
    {
        return await autorAppService.CreateAsync(libro);
    }


[HttpPut]
public async Task UpdateAsync (int id, AutorCrearActualizarDto libro)
{
        await autorAppService.UpdateAsync(id,libro);

}

[HttpDelete]

public async Task<bool>DeleteAsync (int libroId)
{
        return await autorAppService.DeleteAsync(libroId);
}
}