using Microsoft.AspNetCore.Mvc;
using PruebaLibro.Application;

namespace PruebaLibro.HttpApi.Controllers;

[ApiController]
[Route ("[controller]")]

public class EditorialController : ControllerBase
{
    private readonly IEditorialAppService editorialAppService;

    public EditorialController (IEditorialAppService editorialAppService)
    {
        this.editorialAppService =editorialAppService;

    }
[HttpGet]
public ListaPaginada<EditorialDto>GetAll (int limit =10, int offset=0)
{
    return editorialAppService.GetAll(limit,offset);
}


[HttpPost]
    public async Task<EditorialDto> CreateAsync (EditorialCrearActualizarDto libro)
    {
        return await editorialAppService.CreateAsync(libro);
    }


[HttpPut]
public async Task UpdateAsync (int id, EditorialCrearActualizarDto libro)
{
        await editorialAppService.UpdateAsync(id,libro);

}

[HttpDelete]

public async Task<bool>DeleteAsync (int libroId)
{
        return await editorialAppService.DeleteAsync(libroId);
}
}
